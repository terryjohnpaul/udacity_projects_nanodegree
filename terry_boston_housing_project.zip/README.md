Udacity Machine Learning Nanodegree Project 5 on Predicting Boston Housing Prices

The aim of this project is to implement the ideas in Machine Learning related to model evaluation and validation.

It is Project 1 in the Machine Learning Engineer Nanodegree. More specifically,
we will use data related to housing prices in Boston in order to predict the best house price for a sample house.

The main code is in visulas.py.

Alternatively, there is a Python Notebook implementation with the code and further comments on the results.
this is the project done by 
P.Terry John Paul
Pursuing Computer Science Degree

