
This project involves the use of NumPy, Pandas, MatPlotlib, Seaborn and Python to analyse a dataset. 

The dataset I choose was the Titanic Dataset provided by Kaggle.

This repository contains:- copy of the dataset "titanic_data.csv"

HTML version of the report "Titanic Dataset Investigation.html"

iPython notebook - used to generate the report "Titanic Dataset Investigation.ipynb".

This is done by P.Terry John Paul
Pursuing Computer Science Degree
