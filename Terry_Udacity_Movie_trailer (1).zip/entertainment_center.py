import fresh_tomatoes
import media
# billa movie: moviename,storyline,movie poster,youtube trailer url
billa = media.Movie("Billa",
                    "A Gangster with Dual Role",
                    "http://3.bp.blogspot.com/-SRGey51p2kE/T7dnwnH2bvI/AAAAAAAAEbM/n6RUW8wv78g/s1600/5.jpg",  # noqa
                    "https://www.youtube.com/watch?v=NtfYzw_zs5s")

# yennai arindhal: moviename,storyline,movie poster,youtube url
yennai_Arindhal = media.Movie("Yennai Arindhal",
                             "A police officer with his daugter faces this societies serious issue",  # noqa
                             "https://photos.filmibeat.com/ph-big/2015/01/yennai-arindhaal-movie-poster_142199580830.jpg",  # noqa
                             "https://www.youtube.com/watch?v=B7c87SWQg-Y")

# vivegam : movie name,story line,movie poster,youtube url
vivegam = media.Movie("Vivegam",
                      "A INTERPOL agent tries to prove himself not a criminal",
                      "http://www.ssmusic.tv/wp-content/uploads/2017/02/C4ITIJCXUAAI0Bn-copy.jpg",  # noqa
                      "https://www.youtube.com/watch?v=uM7zTAMFRxc")
# arambam : movie name,story line, movie poster, youtube url
arambam = media.Movie("Arambam",
                      "A Indian Police tries to bring back BlackMoney to India",  # noqa
                      "https://badlygood.files.wordpress.com/2013/11/aarambam-audio-coming-soon_1_.jpg",  # noqa
                      "https://www.youtube.com/watch?v=lapUyTJiHOo")
# veeram : movie name,story line,movie poster, youtube trailer url
veeram = media.Movie("Veeram",
                     "A tamil Gangster fight for his Brothers and lovers Family",  # noqa
                     "https://badlygood.files.wordpress.com/2014/01/veeram_poster.jpg",  # noqa
                     "https://www.youtube.com/watch?v=E2jIoTXQdxY")
# vedalam : movie name,story line,movie poster, youtube trailer url
vedalam = media.Movie("Vedalam",
                      "A story of Gangster and his Sister",
                      "http://im.rediff.com/movies/2015/sep/26south1.jpg",
                      "https://www.youtube.com/watch?v=b3WB7ogte-g")
# billa 2: movie name,story line,movie poster, youtube trailer url
billa_2 = media.Movie("Billa-2",
                      "A story of gangster from srilanka",
                      "http://www.ajithfans.com/article-uploads/2012/07/billa2-rocls-570x693.jpg",  # noqa
                      "https://www.youtube.com/watch?v=beOgcOu-vQU")
# mankatha : movie name,storyline,movie poater,youtube trailer url
mankatha = media.Movie("Mankatha",
                       "A Cop Steals the Black Money",
                       "http://www.impawards.com/intl/india/2011/posters/mankatha.jpg",  # noqa
                       "https://www.youtube.com/watch?v=vHESM8iR1JE")
# set  the movies that pass to the media file
movies = [billa, yennai_Arindhal, vivegam, arambam, veeram, vedalam, billa_2, mankatha]  # noqa
# Open the HTML file in a webbrowser via freshtomatoes.py file
fresh_tomatoes.open_movies_page(movies)